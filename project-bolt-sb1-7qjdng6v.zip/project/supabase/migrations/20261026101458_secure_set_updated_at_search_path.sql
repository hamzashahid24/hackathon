/*
# Secure search_path on set_updated_at trigger function

Pins the trigger function's search_path to `public` to remove the
mutable-search_path advisor warning (defense against search_path hijacking).
No behavior change.
*/

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

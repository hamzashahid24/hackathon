/*
# Storage policies for report-photos bucket

1. Purpose
- Public-read access for report photos (they are campus problem photos, shared community content).
- Authenticated + anon upload access so students can upload photos without signing in.
- Allow update/delete so an admin or the reporter can manage photos.

2. Security
- SELECT (read) is public so the app can display photos to any visitor.
- INSERT/UPDATE/DELETE granted to anon + authenticated since the app has no sign-in.
- These are intentionally public/shared files in a campus reporting context.
*/

DROP POLICY IF EXISTS "Public read report photos" ON storage.objects;
CREATE POLICY "Public read report photos" ON storage.objects
  FOR SELECT TO anon, authenticated USING (bucket_id = 'report-photos');

DROP POLICY IF EXISTS "Anyone can upload report photos" ON storage.objects;
CREATE POLICY "Anyone can upload report photos" ON storage.objects
  FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = 'report-photos');

DROP POLICY IF EXISTS "Anyone can update report photos" ON storage.objects;
CREATE POLICY "Anyone can update report photos" ON storage.objects
  FOR UPDATE TO anon, authenticated USING (bucket_id = 'report-photos') WITH CHECK (bucket_id = 'report-photos');

DROP POLICY IF EXISTS "Anyone can delete report photos" ON storage.objects;
CREATE POLICY "Anyone can delete report photos" ON storage.objects
  FOR DELETE TO anon, authenticated USING (bucket_id = 'report-photos');

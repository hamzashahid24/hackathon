/*
# Create reports table for CampusFix - UET

1. Purpose
- Stores campus problem reports submitted by students (broken benches, trash,
  lighting, water leakage, etc.), each with an AI-generated title/category/description,
  a student-entered location, a photo, and a workflow status.

2. New Tables
- `reports`
  - `id` (uuid, primary key)
  - `title` (text, not null) — AI-generated problem title
  - `category` (text, not null) — AI-generated category (e.g. Furniture, Cleanliness, Electrical, Plumbing, Other)
  - `description` (text, not null) — AI-generated detailed description
  - `location` (text, not null) — student-entered location (e.g. "Electrical Dept, Block B, 2nd floor")
  - `status` (text, not null, default 'pending') — workflow status: pending | in_progress | resolved
  - `image_path` (text) — storage path of the uploaded photo (nullable; report may have no photo)
  - `admin_notes` (text) — optional notes set by admin when changing status
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now())

3. Indexes
- `reports_status_idx` on `status` for filtered list/admin views.
- `reports_created_at_idx` on `created_at` for ordering by newest.

4. Constraints
- `reports_status_check` — status must be one of the allowed values.

5. Security
- Enable RLS on `reports`.
- This is a campus-wide reporting app with no sign-in, so data is intentionally
  shared/public: any visitor can create and view reports, and an admin screen
  can update the status. Grant CRUD to `anon` and `authenticated`.
- Policies use `USING (true)` / `WITH CHECK (true)` because the data is
  intentionally public/shared across the campus community (no auth in this app).
*/

CREATE TABLE IF NOT EXISTS reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  category text NOT NULL,
  description text NOT NULL,
  location text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  image_path text,
  admin_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT reports_status_check CHECK (status IN ('pending', 'in_progress', 'resolved'))
);

CREATE INDEX IF NOT EXISTS reports_status_idx ON reports (status);
CREATE INDEX IF NOT EXISTS reports_created_at_idx ON reports (created_at DESC);

ALTER TABLE reports ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON reports TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_reports" ON reports;
CREATE POLICY "anon_select_reports" ON reports FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_reports" ON reports;
CREATE POLICY "anon_insert_reports" ON reports FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_reports" ON reports;
CREATE POLICY "anon_update_reports" ON reports FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_reports" ON reports;
CREATE POLICY "anon_delete_reports" ON reports FOR DELETE
  TO anon, authenticated USING (true);

-- Trigger to keep updated_at in sync on row update
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS reports_set_updated_at ON reports;
CREATE TRIGGER reports_set_updated_at
  BEFORE UPDATE ON reports
  FOR EACH ROW
  EXECUTE FUNCTION set_updated_at();

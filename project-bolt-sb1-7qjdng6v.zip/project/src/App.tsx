import { useCallback, useEffect, useState } from "react";
import BottomNav from "./components/BottomNav";
import ReportPage from "./pages/ReportPage";
import ReportsPage from "./pages/ReportsPage";
import AdminPage from "./pages/AdminPage";
import ReportDetail from "./components/ReportDetail";
import { fetchReports } from "./lib/api";
import type { Report } from "./types";

export type PageId = "report" | "reports" | "admin";

export default function App() {
  const [page, setPage] = useState<PageId>("report");
  const [reports, setReports] = useState<Report[]>([]);
  const [detail, setDetail] = useState<Report | null>(null);

  const refresh = useCallback(() => {
    fetchReports()
      .then(setReports)
      .catch(() => {});
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const pendingCount = reports.filter((r) => r.status === "pending").length;

  function navigate(p: PageId) {
    setPage(p);
    setDetail(null);
    if (p === "reports") refresh();
  }

  return (
    <div className="mx-auto min-h-screen max-w-md bg-slate-50">
      {page === "report" && (
        <ReportPage
          onSubmitted={() => {
            refresh();
            navigate("reports");
          }}
        />
      )}
      {page === "reports" && (
        <ReportsPage onOpenReport={setDetail} pendingCount={pendingCount} />
      )}
      {page === "admin" && <AdminPage />}

      {detail && (
        <ReportDetail
          report={detail}
          onClose={() => setDetail(null)}
          onDeleted={() => {
            setReports((prev) => prev.filter((r) => r.id !== detail.id));
            setDetail(null);
          }}
        />
      )}

      <BottomNav active={page} onNavigate={navigate} pendingCount={pendingCount} />
    </div>
  );
}

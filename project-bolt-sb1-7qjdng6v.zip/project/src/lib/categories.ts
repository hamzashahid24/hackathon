import { CATEGORIES, type ReportCategory } from "../types";

interface CatStyle {
  badge: string;
  ring: string;
  icon: string;
  solid: string;
}

const MAP: Record<ReportCategory, CatStyle> = {
  Furniture: { badge: "bg-amber-100 text-amber-800", ring: "ring-amber-200", icon: "text-amber-600", solid: "bg-amber-500" },
  Cleanliness: { badge: "bg-emerald-100 text-emerald-800", ring: "ring-emerald-200", icon: "text-emerald-600", solid: "bg-emerald-500" },
  Electrical: { badge: "bg-yellow-100 text-yellow-800", ring: "ring-yellow-200", icon: "text-yellow-600", solid: "bg-yellow-500" },
  Plumbing: { badge: "bg-sky-100 text-sky-800", ring: "ring-sky-200", icon: "text-sky-600", solid: "bg-sky-500" },
  Infrastructure: { badge: "bg-slate-100 text-slate-800", ring: "ring-slate-200", icon: "text-slate-600", solid: "bg-slate-500" },
  Safety: { badge: "bg-rose-100 text-rose-800", ring: "ring-rose-200", icon: "text-rose-600", solid: "bg-rose-500" },
  Other: { badge: "bg-violet-100 text-violet-800", ring: "ring-violet-200", icon: "text-violet-600", solid: "bg-violet-500" },
};

export function CATEGORY_STYLE(category: string): CatStyle {
  return MAP[category as ReportCategory] ?? MAP.Other;
}

export { CATEGORIES };

import { supabase } from "./supabase";
import type {
  AnalyzeResult,
  NewReportInput,
  Report,
  ReportStatus,
} from "../types";

const BUCKET = "report-photos";

const CATEGORIES_LIST = [
  "Furniture",
  "Cleanliness",
  "Electrical",
  "Plumbing",
  "Infrastructure",
  "Safety",
  "Other",
];

export async function uploadPhoto(file: Blob, ext = "jpg"): Promise<string> {
  const fileName = `${Date.now()}-${Math.random().toString(36).slice(2, 9)}.${ext}`;
  const { error } = await supabase.storage
    .from(BUCKET)
    .upload(fileName, file, { contentType: file.type || "image/jpeg" });
  if (error) throw new Error(`Upload failed: ${error.message}`);
  return fileName;
}

export function getPublicPhotoUrl(imagePath: string): string {
  const { data } = supabase.storage.from(BUCKET).getPublicUrl(imagePath);
  return data.publicUrl;
}

function fileToBase64(file: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("Could not read image file."));
    reader.readAsDataURL(file);
  });
}

export interface AnalyzeImageResult {
  title: string;
  category: string;
  description: string;
  priority: string;
}

const GEMINI_PROMPT =
  'You are a campus maintenance AI. Look at this image carefully. What is broken? Is it a fan, chair, light, tap, wall, toilet? Return ONLY valid JSON: {"title": "short specific title based on what you see in image", "category": "choose one: Electrical, Furniture, Plumbing, Cleanliness, Other", "description": "detailed 1-2 line description of what you actually see broken in this specific image", "priority": "High/Medium/Low"} Do not use generic text. Describe what is in the image.';

function parseGeminiResponse(text: string): AnalyzeImageResult | null {
  const cleaned = text
    .replace(/```json\s*/gi, "")
    .replace(/```\s*/g, "")
    .trim();

  let parsed: unknown;
  try {
    parsed = JSON.parse(cleaned);
  } catch {
    return null;
  }

  const obj = parsed as Record<string, unknown>;
  const title = typeof obj.title === "string" ? obj.title.trim() : "";
  const category = typeof obj.category === "string" ? obj.category.trim() : "";
  const description =
    typeof obj.description === "string" ? obj.description.trim() : "";
  const priority = typeof obj.priority === "string" ? obj.priority.trim() : "Medium";

  if (!title || !category || !description) return null;

  const normalizedCategory = CATEGORIES_LIST.includes(category) ? category : "Other";
  return { title, category: normalizedCategory, description, priority };
}

// Returns the parsed result, or null if this model should be retried (404/429).
// Throws for real errors so the caller can surface them instead of faking a result.
async function callGemini(
  model: string,
  clean: string,
  apiKey: string,
): Promise<AnalyzeImageResult | null> {
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`;
  const body = {
    contents: [
      {
        parts: [
          { text: GEMINI_PROMPT },
          { inline_data: { mime_type: "image/jpeg", data: clean } },
        ],
      },
    ],
    generationConfig: { temperature: 0.4, maxOutputTokens: 512 },
  };

  const res = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  // 404 = model not found, 429 = rate limit → try the fallback model
  if (res.status === 404 || res.status === 429) return null;

  const json = await res.json().catch(() => null);
  if (!res.ok) {
    const message =
      (json && (json.error?.message || json.error)) ||
      `Gemini request failed (${res.status})`;
    throw new Error(String(message));
  }

  const text: string = json?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
  return parseGeminiResponse(text);
}

export async function analyzeImage(base64: string): Promise<AnalyzeImageResult> {
  const apiKey = import.meta.env.VITE_GEMINI_API_KEY as string | undefined;

  if (!apiKey || apiKey.trim() === "") {
    throw new Error(
      "Gemini API key is missing. Add VITE_GEMINI_API_KEY in the env portal and redeploy.",
    );
  }

  // base64 comes as "data:image/jpeg;base64,...." — strip the prefix.
  const clean = base64.split(",")[1] ?? base64;

  // Primary model first; fall back to gemini-1.5-flash on 404/429.
  const primary = await callGemini("gemini-2.5-flash", clean, apiKey);
  if (primary) return primary;

  const secondary = await callGemini("gemini-1.5-flash", clean, apiKey);
  if (secondary) return secondary;

  // Both models were tried and neither produced a usable result.
  throw new Error(
    "AI could not analyze this image. Please fill in the report details manually.",
  );
}

export async function analyzeProblem(file: Blob): Promise<AnalyzeResult> {
  const dataUrl = await fileToBase64(file);
  const result = await analyzeImage(dataUrl);
  return {
    title: result.title,
    category: result.category,
    description: result.description,
  };
}

export async function createReport(input: NewReportInput): Promise<Report> {
  const { data, error } = await supabase
    .from("reports")
    .insert({
      title: input.title,
      category: input.category,
      description: input.description,
      location: input.location,
      image_path: input.image_path,
      status: "pending",
    })
    .select()
    .single();

  if (error) throw new Error(`Could not create report: ${error.message}`);
  return data as Report;
}

export async function fetchReports(): Promise<Report[]> {
  const { data, error } = await supabase
    .from("reports")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) throw new Error(`Could not load reports: ${error.message}`);
  return (data ?? []) as Report[];
}

export async function updateReportStatus(
  id: string,
  status: ReportStatus,
  adminNotes: string | null = null,
): Promise<Report> {
  const patch: Record<string, unknown> = { status };
  if (adminNotes !== null) patch.admin_notes = adminNotes;
  const { data, error } = await supabase
    .from("reports")
    .update(patch)
    .eq("id", id)
    .select()
    .single();
  if (error) throw new Error(`Could not update status: ${error.message}`);
  return data as Report;
}

export async function deleteReport(id: string): Promise<void> {
  const { error } = await supabase.from("reports").delete().eq("id", id);
  if (error) throw new Error(`Could not delete report: ${error.message}`);
}

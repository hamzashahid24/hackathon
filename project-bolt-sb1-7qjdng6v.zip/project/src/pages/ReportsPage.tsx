import { useEffect, useState } from "react";
import { ListChecks, Loader2, Search, Filter } from "lucide-react";
import Header from "../components/Header";
import ReportCard from "../components/ReportCard";
import EmptyState from "../components/EmptyState";
import { fetchReports, deleteReport } from "../lib/api";
import type { Report, ReportStatus } from "../types";
import { STATUS_LABEL } from "../types";

type FilterKey = "all" | ReportStatus;

const FILTERS: { key: FilterKey; label: string }[] = [
  { key: "all", label: "All" },
  { key: "pending", label: STATUS_LABEL.pending },
  { key: "in_progress", label: STATUS_LABEL.in_progress },
  { key: "resolved", label: STATUS_LABEL.resolved },
];

export default function ReportsPage({
  onOpenReport,
  pendingCount,
}: {
  onOpenReport: (r: Report) => void;
  pendingCount: number;
}) {
  const [reports, setReports] = useState<Report[] | null>(null);
  const [filter, setFilter] = useState<FilterKey>("all");
  const [query, setQuery] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    fetchReports()
      .then((r) => active && setReports(r))
      .catch((e) => active && setError(e instanceof Error ? e.message : "Could not load reports."));
    return () => {
      active = false;
    };
  }, []);

  async function handleDelete(r: Report) {
    if (!confirm(`Delete "${r.title}"? This cannot be undone.`)) return;
    try {
      await deleteReport(r.id);
      setReports((prev) => prev?.filter((x) => x.id !== r.id) ?? null);
    } catch (e) {
      alert(e instanceof Error ? e.message : "Could not delete report.");
    }
  }

  const visible = (reports ?? []).filter((r) => {
    if (filter !== "all" && r.status !== filter) return false;
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      return (
        r.title.toLowerCase().includes(q) ||
        r.location.toLowerCase().includes(q) ||
        r.category.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const counts: Record<FilterKey, number> = {
    all: reports?.length ?? 0,
    pending: reports?.filter((r) => r.status === "pending").length ?? 0,
    in_progress: reports?.filter((r) => r.status === "in_progress").length ?? 0,
    resolved: reports?.filter((r) => r.status === "resolved").length ?? 0,
  };

  return (
    <div className="min-h-screen pb-24">
      <Header
        title="My Reports"
        subtitle={
          reports
            ? `${reports.length} ${reports.length === 1 ? "report" : "reports"} submitted${pendingCount ? ` · ${pendingCount} pending` : ""}`
            : "Loading your reports…"
        }
      />

      <main className="px-5">
        {/* Search */}
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search title, location, category…"
            className="input pl-10"
          />
        </div>

        {/* Filter chips */}
        <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto pb-1">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold ring-1 transition-colors ${
                filter === f.key
                  ? "bg-slate-900 text-white ring-slate-900"
                  : "bg-white text-slate-600 ring-slate-200 hover:bg-slate-50"
              }`}
            >
              {f.label}
              <span
                className={`ml-1.5 ${filter === f.key ? "text-white/70" : "text-slate-400"}`}
              >
                {counts[f.key]}
              </span>
            </button>
          ))}
        </div>

        {/* Body */}
        {error && (
          <p className="mt-6 rounded-xl bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</p>
        )}

        {reports === null && !error && (
          <div className="mt-6 space-y-3">
            {[0, 1, 2].map((i) => (
              <div key={i} className="flex h-24 gap-3 rounded-2xl border border-slate-200 bg-white p-2.5">
                <div className="h-full w-24 shimmer rounded-xl" />
                <div className="flex-1 space-y-2 py-1">
                  <div className="h-3.5 w-2/3 shimmer rounded" />
                  <div className="h-3 w-1/2 shimmer rounded" />
                  <div className="h-5 w-16 shimmer rounded-full" />
                </div>
              </div>
            ))}
          </div>
        )}

        {reports !== null && visible.length === 0 && !error && (
          reports.length === 0 ? (
            <EmptyState
              Icon={ListChecks}
              title="No reports yet"
              message="Report a campus problem by taking a photo — it'll show up here."
            />
          ) : (
            <EmptyState
              Icon={Filter}
              title="No matches"
              message="No reports match your search or filter. Try changing them."
            />
          )
        )}

        {visible.length > 0 && (
          <div className="mt-4 space-y-3">
            {visible.map((r) => (
              <div key={r.id} className="animate-fade-in-up">
                <ReportCard report={r} onClick={onOpenReport} onDelete={handleDelete} />
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

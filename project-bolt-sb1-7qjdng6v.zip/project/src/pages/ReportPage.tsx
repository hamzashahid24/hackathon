import { useEffect, useRef, useState } from "react";
import {
  Camera,
  ImageUp,
  Sparkles,
  Check,
  Loader2,
  X,
  MapPin,
  AlertCircle,
  RotateCcw,
  Send,
  Pencil,
} from "lucide-react";
import Header from "../components/Header";
import { analyzeProblem, createReport, uploadPhoto } from "../lib/api";
import { CATEGORIES } from "../types";
import type { AnalyzeResult } from "../types";

type Stage = "idle" | "photo" | "uploading" | "analyzing" | "review" | "submitting" | "done";

export default function ReportPage({
  onSubmitted,
}: {
  onSubmitted: () => void;
}) {
  const [stage, setStage] = useState<Stage>("idle");
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [imagePath, setImagePath] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [ai, setAi] = useState<AnalyzeResult | null>(null);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<string>("Other");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [editing, setEditing] = useState(false);

  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const photoObjectUrlRef = useRef<string | null>(null);

  useEffect(() => {
    return () => {
      if (photoObjectUrlRef.current) URL.revokeObjectURL(photoObjectUrlRef.current);
    };
  }, []);

  function reset() {
    if (photoObjectUrlRef.current) URL.revokeObjectURL(photoObjectUrlRef.current);
    photoObjectUrlRef.current = null;
    setStage("idle");
    setPhotoUrl(null);
    setImagePath(null);
    setError(null);
    setAi(null);
    setTitle("");
    setCategory("Other");
    setDescription("");
    setLocation("");
    setEditing(false);
  }

  async function handleFile(file: File) {
    setError(null);
    if (!file.type.startsWith("image/")) {
      setError("Please choose an image file.");
      return;
    }
    const url = URL.createObjectURL(file);
    if (photoObjectUrlRef.current) URL.revokeObjectURL(photoObjectUrlRef.current);
    photoObjectUrlRef.current = url;
    setPhotoUrl(url);
    setStage("analyzing");

    try {
      const result = await analyzeProblem(file);
      setAi(result);
      setTitle(result.title);
      setCategory(result.category);
      setDescription(result.description);
      setEditing(false);
      // Upload the photo to storage so it can be attached to the saved report.
      setStage("uploading");
      const path = await uploadPhoto(file, file.type.split("/")[1] || "jpg");
      setImagePath(path);
      setStage("review");
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Something went wrong analyzing the photo.",
      );
      // Still try to upload the photo so the user can submit manually.
      try {
        const path = await uploadPhoto(file, file.type.split("/")[1] || "jpg");
        setImagePath(path);
      } catch {
        // ignore upload error; user can still submit without image path
      }
      setStage("review");
      setEditing(true);
    }
  }

  async function submit() {
    if (!title.trim() || !category || !description.trim() || !location.trim()) {
      setError("Please fill in the title, category, description, and location.");
      return;
    }
    setStage("submitting");
    setError(null);
    try {
      await createReport({
        title: title.trim(),
        category,
        description: description.trim(),
        location: location.trim(),
        image_path: imagePath,
      });
      setStage("done");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not submit report.");
      setStage("review");
    }
  }

  return (
    <div className="min-h-screen pb-24">
      <Header title="Report" subtitle="Snap a photo — AI fills in the report for you." />

      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFile(f);
          e.target.value = "";
        }}
      />
      <input
        ref={galleryInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFile(f);
          e.target.value = "";
        }}
      />

      <main className="px-5">
        {/* IDLE — big camera button */}
        {stage === "idle" && (
          <div className="animate-fade-in-up">
            <button
              onClick={() => cameraInputRef.current?.click()}
              className="group relative mx-auto flex h-64 w-full max-w-sm flex-col items-center justify-center gap-5 overflow-hidden rounded-[2rem] bg-gradient-to-br from-teal-600 via-teal-700 to-cyan-800 text-white shadow-2xl shadow-teal-700/30 transition-transform active:scale-[0.98]"
            >
              <span className="absolute inset-0 rounded-[2rem] ring-1 ring-white/20" />
              <span className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-xl" />
              <span className="absolute -bottom-12 -left-8 h-44 w-44 rounded-full bg-cyan-300/10 blur-xl" />
              <span className="relative flex h-24 w-24 items-center justify-center">
                <span className="absolute inset-0 rounded-full bg-white/20 animate-ring-pulse" />
                <span className="relative flex h-20 w-20 items-center justify-center rounded-full bg-white text-teal-700 shadow-inner">
                  <Camera className="h-9 w-9" strokeWidth={2.2} />
                </span>
              </span>
              <span className="relative text-center">
                <span className="block text-2xl font-extrabold tracking-tight">
                  Report Problem
                </span>
                <span className="mt-1 block text-sm font-medium text-teal-50/80">
                  Tap to take a photo
                </span>
              </span>
            </button>

            <div className="mx-auto mt-4 flex max-w-sm items-center justify-center gap-3">
              <button
                onClick={() => galleryInputRef.current?.click()}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 shadow-sm transition-colors hover:bg-slate-50"
              >
                <ImageUp className="h-4 w-4 text-teal-600" />
                Choose from gallery
              </button>
            </div>

            <ul className="mx-auto mt-7 max-w-sm space-y-2.5 text-sm text-slate-500">
              {[
                "AI identifies the problem from your photo",
                "Report is auto-filled — just add the location",
                "Track status from Pending to Resolved",
              ].map((t) => (
                <li key={t} className="flex items-center gap-2.5">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-teal-100 text-teal-700">
                    <Check className="h-3 w-3" strokeWidth={3} />
                  </span>
                  {t}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* UPLOADING / ANALYZING */}
        {(stage === "uploading" || stage === "analyzing") && photoUrl && (
          <div className="flex flex-col items-center animate-fade-in-up">
            <div className="relative h-72 w-full max-w-sm overflow-hidden rounded-3xl shadow-xl">
              <img src={photoUrl} alt="Report preview" className="h-full w-full object-cover" />
              <div className="absolute inset-0 bg-slate-900/45 backdrop-blur-[2px]" />
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-white">
                <Loader2 className="h-9 w-9 animate-spin" />
                <p className="text-sm font-semibold">
                  {stage === "analyzing" ? "AI is analyzing the problem…" : "Saving photo…"}
                </p>
                {stage === "analyzing" && (
                  <p className="max-w-[16rem] text-center text-xs text-white/80">
                    Identifying the issue, category, and writing a description.
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* REVIEW / SUBMITTING */}
        {(stage === "review" || stage === "submitting") && (
          <div className="animate-fade-in-up space-y-4">
            {photoUrl && (
              <div className="relative h-44 w-full overflow-hidden rounded-2xl shadow-md">
                <img src={photoUrl} alt="Report" className="h-full w-full object-cover" />
                <button
                  onClick={reset}
                  className="absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-slate-900/60 text-white backdrop-blur transition-colors hover:bg-slate-900/80"
                  aria-label="Retake photo"
                >
                  <RotateCcw className="h-4 w-4" />
                </button>
                {ai && !editing && (
                  <span className="absolute bottom-2 left-2 inline-flex items-center gap-1.5 rounded-full bg-emerald-500 px-2.5 py-1 text-xs font-bold text-white shadow-lg">
                    <Sparkles className="h-3.5 w-3.5" />
                    AI-generated
                  </span>
                )}
              </div>
            )}

            {error && (
              <div className="flex items-start gap-2.5 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-3 text-sm text-rose-700">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-sm font-bold uppercase tracking-wide text-slate-500">
                  Report Details
                </h2>
                {ai && (
                  <button
                    onClick={() => setEditing((e) => !e)}
                    className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-semibold transition-colors ${
                      editing
                        ? "bg-teal-600 text-white"
                        : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                    }`}
                  >
                    <Pencil className="h-3.5 w-3.5" />
                    {editing ? "Editing" : "Edit"}
                  </button>
                )}
              </div>

              <div className="space-y-3.5">
                <Field label="Title">
                  <input
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    readOnly={!!ai && !editing}
                    placeholder="Problem title"
                    className={`input ${ai && !editing ? "bg-slate-50 text-slate-700" : ""}`}
                  />
                </Field>

                <Field label="Category">
                  {ai && !editing ? (
                    <div className="rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm font-semibold text-slate-700">
                      {category}
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {CATEGORIES.map((c) => (
                        <button
                          key={c}
                          onClick={() => setCategory(c)}
                          className={`rounded-full px-3 py-1.5 text-xs font-semibold ring-1 transition-colors ${
                            category === c
                              ? "bg-teal-600 text-white ring-teal-600"
                              : "bg-white text-slate-600 ring-slate-200 hover:bg-slate-50"
                          }`}
                        >
                          {c}
                        </button>
                      ))}
                    </div>
                  )}
                </Field>

                <Field label="Description">
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    readOnly={!!ai && !editing}
                    placeholder="Describe the problem…"
                    rows={4}
                    className={`input resize-none ${ai && !editing ? "bg-slate-50 text-slate-700" : ""}`}
                  />
                </Field>

                <Field label="Location" hint="Where on campus?">
                  <div className="relative">
                    <MapPin className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-teal-600" />
                    <input
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="e.g. Electrical Dept, Block B, 2nd floor"
                      className="input pl-9"
                    />
                  </div>
                </Field>
              </div>
            </div>

            <button
              onClick={submit}
              disabled={stage === "submitting"}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-teal-600 px-5 py-3.5 text-base font-bold text-white shadow-lg shadow-teal-600/25 transition-all active:scale-[0.98] hover:bg-teal-700 disabled:opacity-70"
            >
              {stage === "submitting" ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Submitting…
                </>
              ) : (
                <>
                  <Send className="h-5 w-5" />
                  Submit Report
                </>
              )}
            </button>
          </div>
        )}

        {/* DONE */}
        {stage === "done" && (
          <div className="flex flex-col items-center animate-pop-in px-6 pt-16 text-center">
            <div className="flex h-24 w-24 items-center justify-center rounded-full bg-emerald-100">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500 shadow-lg shadow-emerald-500/30">
                <Check className="h-9 w-9 text-white" strokeWidth={3} />
              </div>
            </div>
            <h2 className="mt-5 text-2xl font-extrabold text-slate-900">
              Report Submitted!
            </h2>
            <p className="mt-1.5 max-w-xs text-sm text-slate-500">
              Your problem has been logged. The admin team will review it and update the status.
            </p>
            <div className="mt-7 flex w-full max-w-xs flex-col gap-2.5">
              <button
                onClick={() => onSubmitted()}
                className="rounded-2xl bg-teal-600 px-5 py-3 text-base font-bold text-white shadow-lg shadow-teal-600/25 transition-colors hover:bg-teal-700"
              >
                View My Reports
              </button>
              <button
                onClick={reset}
                className="rounded-2xl border border-slate-200 bg-white px-5 py-3 text-base font-semibold text-slate-600 transition-colors hover:bg-slate-50"
              >
                Report Another Problem
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 flex items-baseline justify-between">
        <span className="text-xs font-bold uppercase tracking-wide text-slate-500">
          {label}
        </span>
        {hint && <span className="text-[11px] text-slate-400">{hint}</span>}
      </span>
      {children}
    </label>
  );
}

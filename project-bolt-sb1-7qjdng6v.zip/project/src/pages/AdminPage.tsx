import { useEffect, useState } from "react";
import {
  ShieldCheck,
  Loader2,
  X,
  Check,
  Clock,
  Loader,
  MapPin,
  Save,
  Calendar,
} from "lucide-react";
import Header from "../components/Header";
import ReportCard from "../components/ReportCard";
import EmptyState from "../components/EmptyState";
import { fetchReports, updateReportStatus } from "../lib/api";
import { getPublicPhotoUrl } from "../lib/api";
import type { Report, ReportStatus } from "../types";
import { STATUS_LABEL } from "../types";
import { CATEGORY_STYLE } from "../lib/categories";

const ORDER: ReportStatus[] = ["pending", "in_progress", "resolved"];

export default function AdminPage() {
  const [reports, setReports] = useState<Report[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<Report | null>(null);

  useEffect(() => {
    let active = true;
    fetchReports()
      .then((r) => active && setReports(r))
      .catch((e) => active && setError(e instanceof Error ? e.message : "Could not load reports."));
    return () => {
      active = false;
    };
  }, []);

  const counts: Record<ReportStatus, number> = {
    pending: reports?.filter((r) => r.status === "pending").length ?? 0,
    in_progress: reports?.filter((r) => r.status === "in_progress").length ?? 0,
    resolved: reports?.filter((r) => r.status === "resolved").length ?? 0,
  };

  function applyUpdate(updated: Report) {
    setReports((prev) =>
      prev?.map((r) => (r.id === updated.id ? updated : r)) ?? null,
    );
    setSelected((s) => (s && s.id === updated.id ? updated : s));
  }

  async function changeStatus(id: string, status: ReportStatus, notes: string) {
    try {
      const updated = await updateReportStatus(id, status, notes || null);
      applyUpdate(updated);
      return true;
    } catch (e) {
      alert(e instanceof Error ? e.message : "Could not update status.");
      return false;
    }
  }

  return (
    <div className="min-h-screen pb-24">
      <Header title="Admin" subtitle="Review reports and update their status." />

      <main className="px-5">
        {/* Stat tiles */}
        <div className="grid grid-cols-3 gap-2.5">
          {ORDER.map((s) => (
            <StatTile key={s} status={s} count={counts[s]} />
          ))}
        </div>

        {error && (
          <p className="mt-5 rounded-xl bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</p>
        )}

        {reports === null && !error && (
          <div className="mt-5 flex justify-center py-10 text-slate-400">
            <Loader2 className="h-7 w-7 animate-spin" />
          </div>
        )}

        {reports !== null && reports.length === 0 && !error && (
          <EmptyState
            Icon={ShieldCheck}
            title="No reports to manage"
            message="When students submit reports, they'll appear here for status updates."
          />
        )}

        {reports !== null && reports.length > 0 && (
          <div className="mt-5 space-y-3">
            <h2 className="px-1 text-xs font-bold uppercase tracking-wide text-slate-500">
              All Reports ({reports.length})
            </h2>
            {reports.map((r) => (
              <div key={r.id} className="animate-fade-in-up">
                <ReportCard report={r} onClick={setSelected} showChevron />
              </div>
            ))}
          </div>
        )}
      </main>

      {selected && (
        <AdminDrawer
          report={selected}
          onClose={() => setSelected(null)}
          onChangeStatus={changeStatus}
        />
      )}
    </div>
  );
}

function StatTile({ status, count }: { status: ReportStatus; count: number }) {
  const meta: Record<ReportStatus, { Icon: typeof Clock; bg: string; text: string; ring: string }> = {
    pending: { Icon: Clock, bg: "bg-amber-50", text: "text-amber-700", ring: "ring-amber-200" },
    in_progress: { Icon: Loader, bg: "bg-sky-50", text: "text-sky-700", ring: "ring-sky-200" },
    resolved: { Icon: Check, bg: "bg-emerald-50", text: "text-emerald-700", ring: "ring-emerald-200" },
  };
  const { Icon, bg, text, ring } = meta[status];
  return (
    <div className={`flex flex-col items-center gap-1.5 rounded-2xl px-2 py-3 ring-1 ${bg} ${ring}`}>
      <Icon className={`h-5 w-5 ${text} ${status === "in_progress" ? "animate-spin-slow" : ""}`} />
      <span className="text-xl font-extrabold text-slate-800">{count}</span>
      <span className={`text-[11px] font-semibold ${text}`}>{STATUS_LABEL[status]}</span>
    </div>
  );
}

function AdminDrawer({
  report,
  onClose,
  onChangeStatus,
}: {
  report: Report;
  onClose: () => void;
  onChangeStatus: (id: string, status: ReportStatus, notes: string) => Promise<boolean>;
}) {
  const [status, setStatus] = useState<ReportStatus>(report.status);
  const [notes, setNotes] = useState(report.admin_notes ?? "");
  const [saving, setSaving] = useState(false);
  const dirty = status !== report.status || notes !== (report.admin_notes ?? "");

  const cat = CATEGORY_STYLE(report.category) ?? CATEGORY_STYLE("Other");
  const photo = report.image_path ? getPublicPhotoUrl(report.image_path) : null;

  async function save() {
    setSaving(true);
    await onChangeStatus(report.id, status, notes);
    setSaving(false);
  }

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end">
      <button
        className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm animate-fade-in-up"
        onClick={onClose}
        aria-label="Close"
      />
      <div className="relative max-h-[88vh] overflow-y-auto rounded-t-3xl bg-white shadow-2xl animate-fade-in-up pb-8">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white/90 px-5 py-3.5 backdrop-blur">
          <h2 className="text-base font-extrabold text-slate-900">Manage Report</h2>
          <button
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-4 px-5 pt-4">
          {photo && (
            <div className="h-48 w-full overflow-hidden rounded-2xl bg-slate-100">
              <img src={photo} alt={report.title} className="h-full w-full object-cover" />
            </div>
          )}

          <div>
            <span className={`inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${cat.badge} ring-1 ${cat.ring}`}>
              {report.category}
            </span>
            <h3 className="mt-1.5 text-lg font-extrabold leading-snug text-slate-900">
              {report.title}
            </h3>
            <p className="mt-1 flex items-center gap-1.5 text-sm text-slate-500">
              <MapPin className="h-4 w-4 text-slate-400" />
              {report.location}
            </p>
            <p className="mt-0.5 flex items-center gap-1.5 text-xs text-slate-400">
              <Calendar className="h-3.5 w-3.5" />
              {new Date(report.created_at).toLocaleString(undefined, {
                dateStyle: "medium",
                timeStyle: "short",
              })}
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5">
            <p className="text-xs font-bold uppercase tracking-wide text-slate-500">
              Description
            </p>
            <p className="mt-1 text-sm leading-relaxed text-slate-700">{report.description}</p>
          </div>

          {/* Status selector */}
          <div>
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">
              Update Status
            </p>
            <div className="grid grid-cols-3 gap-2">
              {ORDER.map((s) => {
                const active = status === s;
                const m: Record<ReportStatus, string> = {
                  pending: "bg-amber-500 ring-amber-500 text-white",
                  in_progress: "bg-sky-500 ring-sky-500 text-white",
                  resolved: "bg-emerald-500 ring-emerald-500 text-white",
                };
                return (
                  <button
                    key={s}
                    onClick={() => setStatus(s)}
                    className={`rounded-xl px-2 py-2.5 text-xs font-bold ring-1 transition-all ${
                      active
                        ? `${m[s]} shadow-sm`
                        : "bg-white text-slate-600 ring-slate-200 hover:bg-slate-50"
                    }`}
                  >
                    {STATUS_LABEL[s]}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Admin notes */}
          <div>
            <p className="mb-1.5 text-xs font-bold uppercase tracking-wide text-slate-500">
              Admin Notes
            </p>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add a note about this report (optional)…"
              rows={3}
              className="input resize-none"
            />
          </div>

          <button
            onClick={save}
            disabled={!dirty || saving}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-teal-600 px-5 py-3.5 text-base font-bold text-white shadow-lg shadow-teal-600/25 transition-all active:scale-[0.98] hover:bg-teal-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {saving ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Saving…
              </>
            ) : (
              <>
                <Save className="h-5 w-5" />
                Save Changes
              </>
            )}
          </button>
          {!dirty && (
            <p className="text-center text-xs text-slate-400">
              No changes to save.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

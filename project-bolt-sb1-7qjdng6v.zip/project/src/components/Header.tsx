import { HardHat } from "lucide-react";

interface Props {
  title: string;
  subtitle?: string;
}

export default function Header({ title, subtitle }: Props) {
  return (
    <header className="px-5 pt-6 pb-4">
      <div className="flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-teal-600 to-cyan-700 shadow-lg shadow-teal-600/20">
          <HardHat className="h-6 w-6 text-white" strokeWidth={2.4} />
        </div>
        <div>
          <h1 className="text-xl font-extrabold tracking-tight text-slate-900">
            CampusFix
          </h1>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-teal-700">
            UET
          </p>
        </div>
      </div>
      {subtitle && (
        <p className="mt-3 text-[15px] font-medium text-slate-500">{subtitle}</p>
      )}
      {/* keep title accessible to screen readers even when subtitle shown */}
      {title && <h2 className="sr-only">{title}</h2>}
    </header>
  );
}

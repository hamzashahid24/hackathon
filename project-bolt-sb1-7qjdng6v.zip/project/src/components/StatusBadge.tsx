import type { ReportStatus } from "../types";
import { STATUS_LABEL } from "../types";
import { Clock, Loader, CheckCircle2 } from "lucide-react";

interface Props {
  status: ReportStatus;
  size?: "sm" | "md";
}

const STYLES: Record<ReportStatus, { bg: string; text: string; ring: string; Icon: typeof Clock; spin?: boolean }> = {
  pending: {
    bg: "bg-amber-50",
    text: "text-amber-700",
    ring: "ring-amber-200",
    Icon: Clock,
  },
  in_progress: {
    bg: "bg-sky-50",
    text: "text-sky-700",
    ring: "ring-sky-200",
    Icon: Loader,
    spin: true,
  },
  resolved: {
    bg: "bg-emerald-50",
    text: "text-emerald-700",
    ring: "ring-emerald-200",
    Icon: CheckCircle2,
  },
};

export default function StatusBadge({ status, size = "sm" }: Props) {
  const s = STYLES[status];
  const { Icon } = s;
  const pad = size === "md" ? "px-3 py-1.5 text-sm" : "px-2.5 py-1 text-xs";
  const iconSize = size === "md" ? "h-4 w-4" : "h-3.5 w-3.5";
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full font-semibold ring-1 ${pad} ${s.bg} ${s.text} ${s.ring}`}
    >
      <Icon className={`${iconSize} ${s.spin ? "animate-spin-slow" : ""}`} />
      {STATUS_LABEL[status]}
    </span>
  );
}

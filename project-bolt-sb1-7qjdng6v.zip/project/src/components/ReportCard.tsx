import { MapPin, Trash2, ChevronRight } from "lucide-react";
import type { Report } from "../types";
import StatusBadge from "./StatusBadge";
import { getPublicPhotoUrl } from "../lib/api";
import { CATEGORY_STYLE } from "../lib/categories";

interface Props {
  report: Report;
  onClick?: (r: Report) => void;
  onDelete?: (r: Report) => void;
  showChevron?: boolean;
}

export default function ReportCard({ report, onClick, onDelete, showChevron = true }: Props) {
  const catStyle = CATEGORY_STYLE(report.category) ?? CATEGORY_STYLE("Other");
  const photo = report.image_path ? getPublicPhotoUrl(report.image_path) : null;

  return (
    <div
      className="group overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-sm transition-all hover:shadow-md hover:border-slate-300"
    >
      <div
        className={`flex cursor-pointer ${onClick ? "" : "cursor-default"}`}
        onClick={() => onClick?.(report)}
        role={onClick ? "button" : undefined}
      >
        {/* Photo */}
        <div className="relative h-24 w-24 shrink-0 overflow-hidden bg-slate-100 sm:h-28 sm:w-28">
          {photo ? (
            <img
              src={photo}
              alt={report.title}
              className="h-full w-full object-cover"
              loading="lazy"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center">
              <MapPin className="h-7 w-7 text-slate-300" />
            </div>
          )}
          <span
            className={`absolute left-1.5 top-1.5 inline-flex items-center rounded-md px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide ${catStyle.badge} ring-1 ${catStyle.ring}`}
          >
            {report.category}
          </span>
        </div>

        {/* Body */}
        <div className="flex flex-1 flex-col justify-between p-3">
          <div className="flex items-start justify-between gap-2">
            <h3 className="line-clamp-2 text-[15px] font-bold text-slate-800 leading-snug">
              {report.title}
            </h3>
            {showChevron && (
              <ChevronRight className="mt-0.5 h-4 w-4 shrink-0 text-slate-300 group-hover:text-slate-400" />
            )}
          </div>

          <p className="mt-0.5 flex items-center gap-1 text-xs text-slate-500">
            <MapPin className="h-3.5 w-3.5 text-slate-400" />
            <span className="line-clamp-1">{report.location}</span>
          </p>

          <div className="mt-2 flex items-center justify-between">
            <StatusBadge status={report.status} />
            {onDelete && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(report);
                }}
                className="flex h-7 w-7 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-rose-50 hover:text-rose-600"
                aria-label="Delete report"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

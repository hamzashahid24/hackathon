import { Camera, ListChecks, ShieldCheck } from "lucide-react";
import type { PageId } from "../App";

interface Props {
  active: PageId;
  onNavigate: (p: PageId) => void;
  pendingCount: number;
}

const ITEMS: { id: PageId; label: string; Icon: typeof Camera }[] = [
  { id: "report", label: "Report", Icon: Camera },
  { id: "reports", label: "My Reports", Icon: ListChecks },
  { id: "admin", label: "Admin", Icon: ShieldCheck },
];

export default function BottomNav({ active, onNavigate, pendingCount }: Props) {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 border-t border-slate-200/80 bg-white/90 backdrop-blur-lg safe-area-pb">
      <div className="mx-auto max-w-md px-2">
        <ul className="flex items-stretch justify-around">
          {ITEMS.map(({ id, label, Icon }) => {
            const isActive = active === id;
            return (
              <li key={id} className="flex-1">
                <button
                  onClick={() => onNavigate(id)}
                  className={`relative flex w-full flex-col items-center gap-1 py-2.5 transition-colors ${
                    isActive ? "text-teal-700" : "text-slate-400 hover:text-slate-600"
                  }`}
                  aria-current={isActive ? "page" : undefined}
                >
                  <span className="relative">
                    <Icon className="h-6 w-6" strokeWidth={isActive ? 2.5 : 2} />
                    {id === "reports" && pendingCount > 0 && (
                      <span className="absolute -right-2 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-amber-500 px-1 text-[10px] font-bold text-white">
                        {pendingCount}
                      </span>
                    )}
                  </span>
                  <span className="text-[11px] font-medium tracking-wide">{label}</span>
                  {isActive && (
                    <span className="absolute top-0 h-0.5 w-8 rounded-full bg-teal-600" />
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}

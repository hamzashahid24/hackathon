import { X, MapPin, Calendar, Clock, Trash2, Tag, FileText } from "lucide-react";
import type { Report } from "../types";
import { STATUS_LABEL } from "../types";
import { getPublicPhotoUrl, deleteReport } from "../lib/api";
import StatusBadge from "./StatusBadge";
import { CATEGORY_STYLE } from "../lib/categories";

interface Props {
  report: Report;
  onClose: () => void;
  onDeleted: (id: string) => void;
}

export default function ReportDetail({ report, onClose, onDeleted }: Props) {
  const photo = report.image_path ? getPublicPhotoUrl(report.image_path) : null;
  const cat = CATEGORY_STYLE(report.category) ?? CATEGORY_STYLE("Other");

  async function handleDelete() {
    if (!confirm(`Delete "${report.title}"? This cannot be undone.`)) return;
    try {
      await deleteReport(report.id);
      onDeleted(report.id);
    } catch (e) {
      alert(e instanceof Error ? e.message : "Could not delete report.");
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end">
      <button
        className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm animate-fade-in-up"
        onClick={onClose}
        aria-label="Close"
      />
      <div className="relative max-h-[90vh] overflow-y-auto rounded-t-3xl bg-white shadow-2xl animate-fade-in-up pb-8">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white/90 px-5 py-3.5 backdrop-blur">
          <h2 className="text-base font-extrabold text-slate-900">Report Details</h2>
          <button
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-4 px-5 pt-4">
          {photo && (
            <div className="h-56 w-full overflow-hidden rounded-2xl bg-slate-100">
              <img src={photo} alt={report.title} className="h-full w-full object-cover" />
            </div>
          )}

          <div className="flex items-center justify-between">
            <span className={`inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${cat.badge} ring-1 ${cat.ring}`}>
              <Tag className="mr-1 h-3 w-3" />
              {report.category}
            </span>
            <StatusBadge status={report.status} size="md" />
          </div>

          <div>
            <h3 className="text-xl font-extrabold leading-snug text-slate-900">
              {report.title}
            </h3>
            <div className="mt-2 space-y-1.5 text-sm text-slate-500">
              <p className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-teal-600" />
                {report.location}
              </p>
              <p className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-slate-400" />
                {new Date(report.created_at).toLocaleString(undefined, {
                  dateStyle: "medium",
                  timeStyle: "short",
                })}
              </p>
              {report.updated_at !== report.created_at && (
                <p className="flex items-center gap-2 text-xs text-slate-400">
                  <Clock className="h-3.5 w-3.5" />
                  Updated {new Date(report.updated_at).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })}
                </p>
              )}
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5">
            <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-slate-500">
              <FileText className="h-3.5 w-3.5" />
              Description
            </p>
            <p className="mt-1.5 text-sm leading-relaxed text-slate-700">
              {report.description}
            </p>
          </div>

          {report.admin_notes && (
            <div className="rounded-xl border border-teal-200 bg-teal-50 p-3.5">
              <p className="text-xs font-bold uppercase tracking-wide text-teal-700">
                Admin Note
              </p>
              <p className="mt-1 text-sm leading-relaxed text-teal-800">
                {report.admin_notes}
              </p>
            </div>
          )}

          <div className="flex items-center gap-2 pt-1">
            <span className="text-xs text-slate-400">
              Status: <span className="font-semibold text-slate-600">{STATUS_LABEL[report.status]}</span>
            </span>
            <div className="flex-1" />
            <button
              onClick={handleDelete}
              className="inline-flex items-center gap-1.5 rounded-xl border border-rose-200 bg-white px-3.5 py-2 text-sm font-semibold text-rose-600 transition-colors hover:bg-rose-50"
            >
              <Trash2 className="h-4 w-4" />
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

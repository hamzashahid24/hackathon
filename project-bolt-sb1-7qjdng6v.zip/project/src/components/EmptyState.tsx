import type { LucideIcon } from "lucide-react";

interface Props {
  Icon: LucideIcon;
  title: string;
  message: string;
}

export default function EmptyState({ Icon, title, message }: Props) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-16 text-center animate-fade-in-up">
      <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-slate-100">
        <Icon className="h-8 w-8 text-slate-400" strokeWidth={1.6} />
      </div>
      <h3 className="mt-4 text-base font-bold text-slate-700">{title}</h3>
      <p className="mt-1 text-sm text-slate-500 max-w-xs">{message}</p>
    </div>
  );
}

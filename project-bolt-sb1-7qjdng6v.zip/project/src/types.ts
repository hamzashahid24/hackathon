export type ReportStatus = "pending" | "in_progress" | "resolved";

export const STATUS_LABEL: Record<ReportStatus, string> = {
  pending: "Pending",
  in_progress: "In Progress",
  resolved: "Resolved",
};

export const CATEGORIES = [
  "Furniture",
  "Cleanliness",
  "Electrical",
  "Plumbing",
  "Infrastructure",
  "Safety",
  "Other",
] as const;

export type ReportCategory = (typeof CATEGORIES)[number];

export interface Report {
  id: string;
  title: string;
  category: string;
  description: string;
  location: string;
  status: ReportStatus;
  image_path: string | null;
  admin_notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface AnalyzeResult {
  title: string;
  category: string;
  description: string;
}

export type NewReportInput = {
  title: string;
  category: string;
  description: string;
  location: string;
  image_path: string | null;
};
